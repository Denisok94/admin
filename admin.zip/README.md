README.md

Basic Configuration
-------------------

Once the extension is installed, simply modify your application configuration as follows:

```php
echo "asds";
```