<?php

namespace denisok94\admin\controllers;

use Yii;
use yii\web\Controller;


class AssignmentController extends Controller
{
    /**
     * Action index
     */
    public function actionIndex()
    {
        return "AssignmentController";
    }
}
