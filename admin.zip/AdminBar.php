<?php
/**
 * @link https://s-denis.ru/
 * @copyright Copyright (c) 2020 S-Denis LLC
 * @license https://s-denis.ru/license/
 */
namespace denisok94\admin;


/**
 * 
 */
class AdminBar
{    
    public function __construct()
    {
        
    }

    /**
     */
    public static function init()
    {
        return "AdminBar"; //
    }
}
